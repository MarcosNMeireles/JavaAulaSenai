package br.com.trabalho.trabalho;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TrabalhoApplicationTests {

	@Test
	void contextLoads() {
	}

}
